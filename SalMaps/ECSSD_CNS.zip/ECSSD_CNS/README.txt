The saliency maps and the evaluation measures of our CNS model on the dataset ECSSD, if you use this result please cite:

Jing Lou*, Huan Wang, Longtao Chen, Fenglei Xu, Qingyuan Xia, Wei Zhu, Mingwu Ren*, "Exploiting Color Name Space for Salient Object Detection," 
Multimedia Tools and Applications, vol. 79, no. 15, pp. 10873�C10897, 2020. doi:10.1007/s11042-019-07970-x

Project webpage: http://www.loujing.com/cns-sod/